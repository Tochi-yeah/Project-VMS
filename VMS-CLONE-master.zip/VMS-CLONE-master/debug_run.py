import eventlet
eventlet.monkey_patch()

from app import create_app, socketio, db
import os
from dotenv import load_dotenv

load_dotenv()

app = create_app()
with app.app_context():

    if __name__ == "__main__":
        #print(os.getenv("DATABASE_URL"))
        #print(db.engine.url)
        socketio.run(app, host="0.0.0.0", port=5000, debug=True)
        #app.run(host="0.0.0.0", port=5000, debug=True)
        